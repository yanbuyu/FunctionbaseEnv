# BIG FAT NOTICE: THIS IS PARTIALLY PYTHON2-BASED CODE
def main():
 
	import sys
	import linecache
	import cmd
	import bdb
	import os
	import re
	import pprint
	import traceback
	import pdb as pdbmodule
	from pdb import Restart
 
	if not sys.argv[2:] or sys.argv[1] in ("--help", "-h"):
		print("usage: pdb.py pipename scriptfile [arg] ...")
		sys.exit(2)
	 
	pipename=sys.argv[1]
	inpipe=pipename+'stdin'
	outpipe=pipename+'stdout'
	del sys.argv[1]		# Remove pipename to keep the rest of script the same
	try:
		os.mkfifo(inpipe)	# We don't care whether it exists or not	
	except:
		pass
	try:
		os.mkfifo(outpipe)	# ...
	except:
		pass
	
	newstdin=open(inpipe,'r')
	newstdout=open(outpipe,'w')
	print('(_xXx_)Pydroid::Pipe opened(_xXx_)',file=newstdout)
	 
	mainpyfile = os.getenv("ANDROID_ENTRYPOINT",sys.argv[1])	 # Get real script filename
	if not os.path.exists(mainpyfile):
		print('Error:', mainpyfile, 'does not exist',file=newstdout)
		sys.exit(1)
 
	del sys.argv[0]		 # Hide "pdb.py" from argument list
		
	fakepyfile = os.getenv("ANDROID_ORIGFNAME",mainpyfile)
	
	# Replace pdb's dir with script's dir in front of module search path.	
	sys.path[0] = os.path.dirname(fakepyfile)
	
	if(True):
		def pydrilny_hack(self, filename):
			# The script has to run in __main__ namespace (or imports from
			# __main__ will break).
			#
			# So we clear up the __main__ and set several special variables
			# (this gets rid of pdb's globals and cleans old variables on restarts).
			import os					
			
			if os.getenv("ANDROID_ENTRYPOINT"):
				statement='import androidembed;'#Kivy detected
			else:
				import sys
				sys.argv[0]=fakepyfile
				statement=''

			import __main__
			__main__.__dict__.clear()
			__main__.__dict__.update({"__name__"    : "__main__",
						  "__file__"    : fakepyfile,
						  "__builtins__": pdbmodule.__builtins__,
						 })
			
			# When bdb sets tracing, a number of call and line events happens
			# BEFORE debugger even reaches user's code (and the exact sequence of
			# events depends on python version). So we take special measures to
			# avoid stopping before we reach the main script (see user_line and
			# user_call for details).
			self._wait_for_mainpyfile = True
			self.mainpyfile = self.canonic(filename)
			self._user_requested_quit = False
			with open(filename, "rb") as fp:
				statement = "exec(compile(%r, %r, 'exec'))" % (fp.read(), self.mainpyfile)
			self.run(statement)
		pdbmodule.Pdb._runscript=pydrilny_hack
	
	# Note on saving/restoring sys.argv: it's a good idea when sys.argv was
	# modified by the script being debugged. It's a bad idea when it was
	# changed by the user from the command line. There is a "restart" command
	# which allows explicit specification of command line arguments.
	pdb = pdbmodule.Pdb(stdin=newstdin,stdout=newstdout)
	
	pdb.prompt = '(Pdb_iiec)\n'
	if True:
		try:
			pdb._runscript(mainpyfile)
			if pdb._user_requested_quit:
				return
			print("The program finished and will not be restarted",file=newstdout)
		except Restart:
			print("Restarting", mainpyfile, "with arguments:",file=newstdout)
			print("\t" + " ".join(sys.argv[1:]),file=newstdout)
		except SystemExit:
			# In most cases SystemExit does not warrant a post-mortem session.
			print("The program exited via sys.exit(). Exit status: ", end=' ',file=newstdout)
			print(sys.exc_info()[1],file=newstdout)
		except SyntaxError:
			traceback.print_exc(file=newstdout)
			sys.exit(1)
		except:
			traceback.print_exc(file=newstdout)
			print("Uncaught exception. Entering post mortem debugging",file=newstdout)
			print("Running 'cont' or 'step' will restart the program",file=newstdout)
			t = sys.exc_info()[2]
			pdb.interaction(None, t)
			print("Post mortem debugger finished. The " + mainpyfile + 
				  " will be restarted",file=newstdout)
 
 
# When invoked as main program, invoke the debugger on a script
if __name__ == '__main__':
	main()

