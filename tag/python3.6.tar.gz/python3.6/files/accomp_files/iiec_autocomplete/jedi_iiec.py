import sys
import jedi
from struct import unpack

def recv_basic(torecv):
    total_data=[]
    rcvd = 0
    while rcvd<torecv:
        data = sys.stdin.read(torecv-rcvd)
        rcvd += len(data)
        total_data.append(data)
    return ''.join(total_data)

while (1==1):
	source = '\n'

	num_lines = unpack('<I',sys.stdin.read(4))[0]
	char_num = unpack('<I',sys.stdin.read(4))[0]
	text_len = unpack('<I',sys.stdin.read(4))[0]

	source = source + recv_basic(text_len)

	script = jedi.Script(source, num_lines+1, char_num, 'example.py')
	completions = script.completions() 
	res = ''                                     
	for a in completions:
		res = res + a.name + '\n'

	res = res + "###iiec_splitter###" 

	for a in completions:
		res = res + a.complete + '\n'
	res = res + "###iiec_end_of_output###" + '\n'
	sys.stdout.write(res)
	sys.stdout.flush()
	


