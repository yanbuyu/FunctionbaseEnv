import io
import sys

if (sys.version_info[0]>2):
	import builtins as __builtin__
	stdin = sys.stdin.buffer
else:
	import __builtin__
	stdin = sys.stdin



from struct import unpack

bkpopen=__builtin__.open

source_code = ''



def recv_basic(torecv):
	total_data=[]
	rcvd = 0
	while rcvd<torecv:
		data = stdin.read(torecv-rcvd)
		rcvd += len(data)
		total_data.append(data)
	
	if (sys.version_info[0]>2):
		return b''.join(total_data)		
	else:
		return ''.join(total_data)

def myopen(*args, **kwargs):
	if args[0]=="/system/bin/linker":
		if (sys.version_info[0]>2) and (len(args)<2 or not 'b' in args[1]):
			return io.StringIO(str(source_code, 'utf-8'))		
		else:
			return io.BytesIO(source_code) 
	else:
		return bkpopen(*args,**kwargs)

__builtin__.open=myopen
sys.argv[:]=['pylint','/system/bin/linker','--persistent=n','--reports=n','--output-format=parseable','--msg-template=\'{C}:{line}:{column}:{obj}:{msg}:{msg_id}\'']

import pylint

def run_with_no_exit():
	from astroid import MANAGER
	MANAGER.clear_cache()
	from pylint.lint import Run
	Run(sys.argv[1:], exit=False)


while(1==1):
	text_len = unpack('<I', stdin.read(4))[0]
	source_code = recv_basic(text_len)
	
	run_with_no_exit()
	sys.stdout.write('===iiec_spec_sepa_string_c2782e1248daf7d3a9fa0eccc2c3870e===\n')
	sys.stdout.flush()



